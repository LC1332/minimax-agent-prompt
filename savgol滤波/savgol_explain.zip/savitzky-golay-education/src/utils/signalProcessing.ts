/**
 * Signal Processing Utilities for Savitzky-Golay Filter Education
 * Implements triangular filtering and Savitzky-Golay differentiation
 */

/**
 * Generates a random binary signal following specified pattern
 * Pattern: 3-15 ones followed by two zeros, with 50% chance of appending ten zeros
 */
export function generateRandomSignal(): number[] {
  const signal: number[] = [];
  
  while (signal.length < 100) {
    // Generate 3-15 ones
    const onesCount = Math.floor(Math.random() * 13) + 3; // 3 to 15
    for (let i = 0; i < onesCount; i++) {
      signal.push(1);
    }
    
    // Add two zeros
    signal.push(0, 0);
    
    // 50% chance to add ten zeros
    if (Math.random() < 0.5) {
      for (let i = 0; i < 10; i++) {
        signal.push(0);
      }
    }
  }
  
  return signal.slice(0, 100); // Trim to exactly 100 points
}

/**
 * Triangular filter implementation
 * h[t] = 1 - |t|/15 for t ∈ [-15, 15]
 */
export function triangularFilter(signal: number[]): number[] {
  const filtered: number[] = [];
  const filterWidth = 15;
  
  for (let i = 0; i < signal.length; i++) {
    let sum = 0;
    let weightSum = 0;
    
    for (let t = -filterWidth; t <= filterWidth; t++) {
      const sampleIndex = i + t;
      if (sampleIndex >= 0 && sampleIndex < signal.length) {
        const weight = 1 - Math.abs(t) / filterWidth;
        sum += signal[sampleIndex] * weight;
        weightSum += weight;
      }
    }
    
    filtered[i] = weightSum > 0 ? sum / weightSum : 0;
  }
  
  return filtered;
}

/**
 * Matrix operations for polynomial fitting
 */
class Matrix {
  constructor(public data: number[][]) {}
  
  static multiply(a: Matrix, b: Matrix): Matrix {
    const result: number[][] = [];
    for (let i = 0; i < a.data.length; i++) {
      result[i] = [];
      for (let j = 0; j < b.data[0].length; j++) {
        let sum = 0;
        for (let k = 0; k < a.data[0].length; k++) {
          sum += a.data[i][k] * b.data[k][j];
        }
        result[i][j] = sum;
      }
    }
    return new Matrix(result);
  }
  
  static transpose(matrix: Matrix): Matrix {
    const result: number[][] = [];
    for (let j = 0; j < matrix.data[0].length; j++) {
      result[j] = [];
      for (let i = 0; i < matrix.data.length; i++) {
        result[j][i] = matrix.data[i][j];
      }
    }
    return new Matrix(result);
  }
  
  static inverse(matrix: Matrix): Matrix {
    const n = matrix.data.length;
    const augmented: number[][] = [];
    
    // Create augmented matrix [A|I]
    for (let i = 0; i < n; i++) {
      augmented[i] = [...matrix.data[i]];
      for (let j = 0; j < n; j++) {
        augmented[i][n + j] = i === j ? 1 : 0;
      }
    }
    
    // Gaussian elimination
    for (let i = 0; i < n; i++) {
      // Find pivot
      let maxRow = i;
      for (let k = i + 1; k < n; k++) {
        if (Math.abs(augmented[k][i]) > Math.abs(augmented[maxRow][i])) {
          maxRow = k;
        }
      }
      
      // Swap rows
      [augmented[i], augmented[maxRow]] = [augmented[maxRow], augmented[i]];
      
      // Make diagonal 1
      const pivot = augmented[i][i];
      for (let j = 0; j < 2 * n; j++) {
        augmented[i][j] /= pivot;
      }
      
      // Eliminate column
      for (let k = 0; k < n; k++) {
        if (k !== i) {
          const factor = augmented[k][i];
          for (let j = 0; j < 2 * n; j++) {
            augmented[k][j] -= factor * augmented[i][j];
          }
        }
      }
    }
    
    // Extract inverse matrix
    const result: number[][] = [];
    for (let i = 0; i < n; i++) {
      result[i] = augmented[i].slice(n);
    }
    
    return new Matrix(result);
  }
}

/**
 * Fits a polynomial of given order to data points
 */
function fitPolynomial(xValues: number[], yValues: number[], order: number): number[] {
  const n = xValues.length;
  
  // Create Vandermonde matrix
  const A: number[][] = [];
  for (let i = 0; i < n; i++) {
    A[i] = [];
    for (let j = 0; j <= order; j++) {
      A[i][j] = Math.pow(xValues[i], j);
    }
  }
  
  // Create y vector as matrix
  const y: number[][] = [];
  for (let i = 0; i < n; i++) {
    y[i] = [yValues[i]];
  }
  
  const matrixA = new Matrix(A);
  const matrixY = new Matrix(y);
  
  // Solve normal equation: (A^T A) c = A^T y
  const AT = Matrix.transpose(matrixA);
  const ATA = Matrix.multiply(AT, matrixA);
  const ATy = Matrix.multiply(AT, matrixY);
  
  try {
    const ATAInv = Matrix.inverse(ATA);
    const coefficients = Matrix.multiply(ATAInv, ATy);
    return coefficients.data.map(row => row[0]);
  } catch (error) {
    // Fallback to simple linear fit if matrix is singular
    console.warn('Matrix inversion failed, using linear approximation');
    return [yValues[Math.floor(n/2)], 0, 0, 0];
  }
}

/**
 * Evaluates polynomial with given coefficients at x
 */
function evaluatePolynomial(coefficients: number[], x: number): number {
  let result = 0;
  for (let i = 0; i < coefficients.length; i++) {
    result += coefficients[i] * Math.pow(x, i);
  }
  return result;
}

/**
 * Evaluates polynomial derivative with given coefficients at x
 */
function evaluatePolynomialDerivative(coefficients: number[], x: number): number {
  let result = 0;
  for (let i = 1; i < coefficients.length; i++) {
    result += i * coefficients[i] * Math.pow(x, i - 1);
  }
  return result;
}

/**
 * Savitzky-Golay filter for signal differentiation
 * Uses window size of 21 and polynomial order of 3 (cubic)
 */
export function savitzkyGolayDerivative(signal: number[]): {
  derivative: number[];
  windowData: Array<{
    center: number;
    window: number[];
    xValues: number[];
    yValues: number[];
    coefficients: number[];
    fittedCurve: { x: number; y: number }[];
  }>;
} {
  const windowSize = 21;
  const polyOrder = 3;
  const halfWindow = Math.floor(windowSize / 2);
  
  const derivative: number[] = [];
  const windowData: Array<{
    center: number;
    window: number[];
    xValues: number[];
    yValues: number[];
    coefficients: number[];
    fittedCurve: { x: number; y: number }[];
  }> = [];
  
  for (let i = 0; i < signal.length; i++) {
    const startIdx = Math.max(0, i - halfWindow);
    const endIdx = Math.min(signal.length - 1, i + halfWindow);
    
    const xValues: number[] = [];
    const yValues: number[] = [];
    const windowIndices: number[] = [];
    
    for (let j = startIdx; j <= endIdx; j++) {
      xValues.push(j - i); // Relative position to center
      yValues.push(signal[j]);
      windowIndices.push(j);
    }
    
    // Fit cubic polynomial
    const coefficients = fitPolynomial(xValues, yValues, polyOrder);
    
    // Calculate derivative at center point (x = 0)
    const derivativeValue = evaluatePolynomialDerivative(coefficients, 0);
    derivative[i] = derivativeValue;
    
    // Generate fitted curve for visualization
    const fittedCurve: { x: number; y: number }[] = [];
    for (let x = -halfWindow; x <= halfWindow; x += 0.5) {
      const y = evaluatePolynomial(coefficients, x);
      fittedCurve.push({ x: i + x, y });
    }
    
    windowData[i] = {
      center: i,
      window: windowIndices,
      xValues,
      yValues,
      coefficients,
      fittedCurve
    };
  }
  
  return { derivative, windowData };
}

/**
 * Generate derivative intensity bars for visualization
 */
export function generateDerivativeBars(
  smoothedSignal: number[],
  derivative: number[],
  scaleFactor: number = 3
): Array<{ x: number; y1: number; y2: number; value: number; color: string }> {
  return smoothedSignal.map((p_t, index) => {
    const dp_dt = derivative[index];
    const y1 = p_t;
    const y2 = p_t + scaleFactor * dp_dt;
    const color = dp_dt >= 0 ? '#10b981' : '#ef4444'; // Green for positive, red for negative
    
    return {
      x: index,
      y1,
      y2,
      value: dp_dt,
      color
    };
  });
}

/**
 * Process complete signal pipeline
 */
export function processSignal(rawSignal: number[]) {
  const smoothedSignal = triangularFilter(rawSignal);
  const { derivative, windowData } = savitzkyGolayDerivative(smoothedSignal);
  const derivativeBars = generateDerivativeBars(smoothedSignal, derivative);
  
  return {
    rawSignal,
    smoothedSignal,
    derivative,
    windowData,
    derivativeBars
  };
}
