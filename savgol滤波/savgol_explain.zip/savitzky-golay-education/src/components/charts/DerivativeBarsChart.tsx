import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';

interface DerivativeBarsChartProps {
  smoothedSignal: number[];
  derivative: number[];
  currentTimeIndex: number;
  scaleFactor?: number;
}

const DerivativeBarsChart: React.FC<DerivativeBarsChartProps> = ({
  smoothedSignal,
  derivative,
  currentTimeIndex,
  scaleFactor = 3
}) => {
  // Prepare data for the chart
  const data = smoothedSignal.map((p_t, index) => {
    const dp_dt = derivative[index];
    return {
      index,
      smoothed: p_t,
      derivative: dp_dt,
      barTop: p_t + scaleFactor * dp_dt,
      barBottom: p_t
    };
  });

  // Custom component to render derivative bars
  const DerivativeBar = ({ x, y1, y2, color }: { x: number; y1: number; y2: number; color: string }) => {
    // Convert chart coordinates to SVG coordinates would require access to chart scales
    // For now, we'll use a simpler approach with the Line component
    return null;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0]?.payload;
      if (data) {
        return (
          <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
            <p className="text-sm font-medium">{`Time: ${label}`}</p>
            <p className="text-sm text-green-600">{`Smoothed: ${data.smoothed.toFixed(4)}`}</p>
            <p className="text-sm text-blue-600">{`Derivative: ${data.derivative.toFixed(4)}`}</p>
            <p className="text-sm text-gray-600">{`Bar extends from ${data.barBottom.toFixed(4)} to ${data.barTop.toFixed(4)}`}</p>
          </div>
        );
      }
    }
    return null;
  };

  // Create SVG elements for derivative bars
  const createDerivativeBars = () => {
    return smoothedSignal.map((p_t, index) => {
      const dp_dt = derivative[index];
      const color = dp_dt >= 0 ? '#10b981' : '#ef4444';
      const barTop = p_t + scaleFactor * dp_dt;
      
      // We'll render these as custom SVG elements overlay
      return {
        index,
        p_t,
        barTop,
        color,
        derivative: dp_dt
      };
    });
  };

  const derivativeBars = createDerivativeBars();

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Derivative Intensity Visualization
        </h3>
        <div className="text-sm text-gray-600 space-y-1">
          <p><strong>Bars extend from:</strong> p(t) to p(t) + {scaleFactor} × dp/dt</p>
          <p>
            <span className="inline-flex items-center gap-1">
              <span className="w-3 h-1 bg-green-500"></span>
              <span>Green: Increasing signal (positive derivative)</span>
            </span>
          </p>
          <p>
            <span className="inline-flex items-center gap-1">
              <span className="w-3 h-1 bg-red-500"></span>
              <span>Red: Decreasing signal (negative derivative)</span>
            </span>
          </p>
        </div>
      </div>

      <div className="relative">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="index" 
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
            />
            <Tooltip content={<CustomTooltip />} />
            
            {/* Smoothed signal baseline */}
            <Line
              type="monotone"
              dataKey="smoothed"
              stroke="#10b981"
              strokeWidth={2}
              dot={false}
              name="Smoothed Signal p(t)"
            />
            
            {/* Top of bars (for reference) */}
            <Line
              type="monotone"
              dataKey="barTop"
              stroke="transparent"
              strokeWidth={0}
              dot={false}
              name="Bar Tops"
            />
            
            {/* Current time indicator */}
            <ReferenceLine 
              x={currentTimeIndex} 
              stroke="#dc2626" 
              strokeWidth={2}
              strokeDasharray="4 4"
            />
          </LineChart>
        </ResponsiveContainer>

        {/* Overlay for derivative bars */}
        <div className="absolute inset-0 pointer-events-none">
          <svg className="w-full h-full">
            {/* We'll implement custom bars here using percentage coordinates */}
            {derivativeBars.map((bar, index) => {
              // Calculate approximate positions (simplified)
              const xPercent = (index / (smoothedSignal.length - 1)) * 100;
              const yRange = Math.max(...smoothedSignal) - Math.min(...smoothedSignal);
              const yMin = Math.min(...smoothedSignal);
              
              const y1Percent = 100 - ((bar.p_t - yMin) / yRange) * 80; // 80% of height for chart area
              const y2Percent = 100 - ((bar.barTop - yMin) / yRange) * 80;
              
              // Only show bars for every 3rd point to avoid clutter
              if (index % 3 !== 0) return null;
              
              return (
                <line
                  key={index}
                  x1={`${xPercent}%`}
                  y1={`${y1Percent}%`}
                  x2={`${xPercent}%`}
                  y2={`${y2Percent}%`}
                  stroke={bar.color}
                  strokeWidth="2"
                  opacity="0.7"
                />
              );
            })}
          </svg>
        </div>
      </div>

      {/* Current value display */}
      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
        <div className="text-sm">
          <strong>At t = {currentTimeIndex}:</strong>
          <div className="mt-1 grid grid-cols-2 gap-4">
            <div>
              <span className="text-gray-600">Smoothed value:</span>
              <span className="ml-2 font-mono">{smoothedSignal[currentTimeIndex]?.toFixed(4) || '0.0000'}</span>
            </div>
            <div>
              <span className="text-gray-600">Derivative:</span>
              <span className={`ml-2 font-mono ${derivative[currentTimeIndex] >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {derivative[currentTimeIndex]?.toFixed(4) || '0.0000'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DerivativeBarsChart;
