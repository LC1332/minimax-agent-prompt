import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Cell,
  ReferenceLine
} from 'recharts';

interface SGWindowVisualizationProps {
  windowData: {
    center: number;
    window: number[];
    xValues: number[];
    yValues: number[];
    coefficients: number[];
    fittedCurve: { x: number; y: number }[];
  };
  smoothedSignal: number[];
  currentTimeIndex: number;
}

const SGWindowVisualization: React.FC<SGWindowVisualizationProps> = ({
  windowData,
  smoothedSignal,
  currentTimeIndex
}) => {
  // Prepare data for visualization
  const windowPoints = windowData.window.map((index, i) => ({
    x: index,
    y: smoothedSignal[index],
    relativeX: windowData.xValues[i],
    isCenter: index === currentTimeIndex,
    inWindow: true
  }));

  // All signal points for context
  const allPoints = smoothedSignal.map((value, index) => ({
    x: index,
    y: value,
    inWindow: windowData.window.includes(index),
    isCenter: index === currentTimeIndex
  }));

  // Fitted polynomial curve
  const fittedCurveData = windowData.fittedCurve.map(point => ({
    x: point.x,
    y: point.y
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="text-sm font-medium">{`Time: ${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {`${entry.name}: ${entry.value.toFixed(4)}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const formatCoefficients = () => {
    const [c0, c1, c2, c3] = windowData.coefficients;
    return `f(x) = ${c0.toFixed(3)} + ${c1.toFixed(3)}x + ${c2.toFixed(3)}x² + ${c3.toFixed(3)}x³`;
  };

  const derivative = windowData.coefficients[1]; // First derivative at x=0

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Savitzky-Golay Window Analysis (t = {currentTimeIndex})
        </h3>
        <div className="text-sm text-gray-600 space-y-1">
          <p><strong>Window Size:</strong> 21 points (±10 from center)</p>
          <p><strong>Polynomial Order:</strong> 3 (cubic)</p>
          <p><strong>Fitted Polynomial:</strong> <code className="text-xs bg-gray-100 px-1 py-0.5 rounded">{formatCoefficients()}</code></p>
          <p><strong>Derivative at center:</strong> <span className={`font-medium ${derivative >= 0 ? 'text-green-600' : 'text-red-600'}`}>{derivative.toFixed(4)}</span></p>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="x"
            domain={['dataMin - 5', 'dataMax + 5']}
            type="number"
            stroke="#6b7280"
            fontSize={12}
          />
          <YAxis 
            domain={['dataMin - 0.1', 'dataMax + 0.1']}
            stroke="#6b7280"
            fontSize={12}
          />
          <Tooltip content={<CustomTooltip />} />
          
          {/* Background signal points (not in window) */}
          <Line
            data={allPoints}
            type="monotone"
            dataKey="y"
            stroke="#d1d5db"
            strokeWidth={1}
            dot={false}
            name="Full Signal"
          />
          
          {/* Window points */}
          <Line
            data={windowPoints}
            type="monotone"
            dataKey="y"
            stroke="#3b82f6"
            strokeWidth={0}
            dot={{
              fill: '#3b82f6',
              strokeWidth: 2,
              r: 4
            }}
            name="Window Points"
          />
          
          {/* Fitted polynomial curve */}
          <Line
            data={fittedCurveData}
            type="monotone"
            dataKey="y"
            stroke="#f59e0b"
            strokeWidth={3}
            dot={false}
            name="Fitted Polynomial"
          />
          
          {/* Center point highlight */}
          <ReferenceLine 
            x={currentTimeIndex} 
            stroke="#dc2626" 
            strokeWidth={2}
            strokeDasharray="4 4"
            label={{ value: "Center", position: "top" }}
          />
        </LineChart>
      </ResponsiveContainer>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-gray-300 rounded-full"></div>
          <span>Full Signal</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span>Window Points</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-1 bg-yellow-500"></div>
          <span>Fitted Polynomial</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-1 bg-red-600 border-dashed border-t-2"></div>
          <span>Current Time</span>
        </div>
      </div>
    </div>
  );
};

export default SGWindowVisualization;
