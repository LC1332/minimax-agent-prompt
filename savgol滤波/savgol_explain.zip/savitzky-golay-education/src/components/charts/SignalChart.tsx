import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Cell,
  BarChart,
  Bar
} from 'recharts';

interface SignalChartProps {
  data: Array<{
    index: number;
    raw: number;
    smoothed: number;
    derivative: number;
  }>;
  derivativeBars: Array<{
    x: number;
    y1: number;
    y2: number;
    value: number;
    color: string;
  }>;
  currentTimeIndex: number;
  title: string;
  showType: 'raw' | 'smoothed' | 'derivative' | 'all';
  height?: number;
}

const SignalChart: React.FC<SignalChartProps> = ({
  data,
  derivativeBars,
  currentTimeIndex,
  title,
  showType,
  height = 300
}) => {
  const formatTooltip = (value: any, name: string) => {
    if (typeof value === 'number') {
      return [value.toFixed(4), name];
    }
    return [value, name];
  };

  const renderChart = () => {
    if (showType === 'derivative') {
      // Special rendering for derivative with colored bars
      const derivativeData = data.map((point, index) => ({
        index: point.index,
        derivative: point.derivative,
        smoothed: point.smoothed,
        barHeight: Math.abs(point.derivative) * 3,
        barColor: point.derivative >= 0 ? '#10b981' : '#ef4444'
      }));

      return (
        <ResponsiveContainer width="100%" height={height}>
          <LineChart data={derivativeData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="index" 
              stroke="#6b7280"
              fontSize={12}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
            />
            <Tooltip 
              formatter={formatTooltip}
              labelStyle={{ color: '#374151' }}
              contentStyle={{ 
                backgroundColor: '#f9fafb', 
                border: '1px solid #d1d5db',
                borderRadius: '8px'
              }}
            />
            
            {/* Smoothed signal baseline */}
            <Line
              type="monotone"
              dataKey="smoothed"
              stroke="#6b7280"
              strokeWidth={1}
              dot={false}
              strokeDasharray="2 2"
              name="Smoothed Signal"
            />
            
            {/* Derivative line */}
            <Line
              type="monotone"
              dataKey="derivative"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={false}
              name="Derivative"
            />
            
            {/* Current time indicator */}
            <ReferenceLine 
              x={currentTimeIndex} 
              stroke="#dc2626" 
              strokeWidth={2}
              strokeDasharray="4 4"
            />
          </LineChart>
        </ResponsiveContainer>
      );
    }

    return (
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="index" 
            stroke="#6b7280"
            fontSize={12}
          />
          <YAxis 
            stroke="#6b7280"
            fontSize={12}
          />
          <Tooltip 
            formatter={formatTooltip}
            labelStyle={{ color: '#374151' }}
            contentStyle={{ 
              backgroundColor: '#f9fafb', 
              border: '1px solid #d1d5db',
              borderRadius: '8px'
            }}
          />
          
          {/* Raw signal */}
          {(showType === 'raw' || showType === 'all') && (
            <Line
              type="stepAfter"
              dataKey="raw"
              stroke="#ef4444"
              strokeWidth={2}
              dot={false}
              name="Raw Signal A(t)"
            />
          )}
          
          {/* Smoothed signal */}
          {(showType === 'smoothed' || showType === 'all') && (
            <Line
              type="monotone"
              dataKey="smoothed"
              stroke="#10b981"
              strokeWidth={2}
              dot={false}
              name="Smoothed Signal p(t)"
            />
          )}
          
          {/* Derivative */}
          {showType === 'all' && (
            <Line
              type="monotone"
              dataKey="derivative"
              stroke="#3b82f6"
              strokeWidth={2}
              dot={false}
              name="Derivative dp/dt"
            />
          )}
          
          {/* Current time indicator */}
          <ReferenceLine 
            x={currentTimeIndex} 
            stroke="#dc2626" 
            strokeWidth={2}
            strokeDasharray="4 4"
          />
        </LineChart>
      </ResponsiveContainer>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">{title}</h3>
      {renderChart()}
    </div>
  );
};

export default SignalChart;
