import React, { useState } from 'react';
import { ChevronDown, ChevronRight, BookOpen, Calculator, History, Lightbulb } from 'lucide-react';

interface EducationalSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

const EducationalSection: React.FC<EducationalSectionProps> = ({ 
  title, 
  icon, 
  children, 
  defaultOpen = false 
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <button
        className="w-full px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors duration-200 flex items-center justify-between text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-3">
          {icon}
          <span className="font-semibold text-gray-900">{title}</span>
        </div>
        {isOpen ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
      </button>
      {isOpen && (
        <div className="p-4 bg-white">
          {children}
        </div>
      )}
    </div>
  );
};

const EducationalContent: React.FC = () => {
  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Understanding Savitzky-Golay Signal Differentiation
        </h2>
        <p className="text-gray-600 max-w-3xl mx-auto">
          Explore how the Savitzky-Golay filter transforms noisy signals into smooth derivatives 
          through polynomial fitting. This interactive tool demonstrates the mathematical principles 
          behind one of the most widely used signal processing techniques.
        </p>
      </div>

      <EducationalSection
        title="What is Signal Processing?"
        icon={<BookOpen className="w-5 h-5 text-blue-600" />}
        defaultOpen={true}
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            Signal processing is the art and science of extracting meaningful information from data. 
            In our daily lives, we encounter signals everywhere - from the sound waves of music 
            to the digital data streaming through our devices.
          </p>
          
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Why Do We Need Signal Processing?</h4>
            <ul className="list-disc list-inside space-y-1 text-blue-800">
              <li><strong>Noise Reduction:</strong> Real-world signals are often corrupted by unwanted noise</li>
              <li><strong>Feature Extraction:</strong> We want to identify important patterns and trends</li>
              <li><strong>Derivative Analysis:</strong> Understanding how signals change over time</li>
              <li><strong>Data Compression:</strong> Representing information more efficiently</li>
            </ul>
          </div>

          <p className="text-gray-700">
            In this demonstration, we start with a simple binary signal (containing only 0s and 1s) 
            and show how mathematical techniques can reveal its underlying structure and rate of change.
          </p>
        </div>
      </EducationalSection>

      <EducationalSection
        title="History of the Savitzky-Golay Filter"
        icon={<History className="w-5 h-5 text-green-600" />}
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            The Savitzky-Golay filter was developed in 1964 by Abraham Savitzky and Marcel J.E. Golay, 
            two brilliant scientists working at different institutions who revolutionized digital signal processing.
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">Abraham Savitzky</h4>
              <p className="text-green-800 text-sm">
                A chemist at DuPont who was working on spectroscopic analysis. He needed a way to 
                smooth noisy spectral data while preserving important peak information.
              </p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">Marcel J.E. Golay</h4>
              <p className="text-green-800 text-sm">
                A mathematician and engineer at Bell Labs, known for his work in coding theory 
                and information theory. He provided the mathematical foundation for the filter.
              </p>
            </div>
          </div>

          <div className="bg-amber-50 p-4 rounded-lg">
            <h4 className="font-semibold text-amber-900 mb-2">Revolutionary Impact</h4>
            <p className="text-amber-800">
              Their 1964 paper "Smoothing and Differentiation of Data by Simplified Least Squares Procedures" 
              became one of the most cited papers in analytical chemistry and signal processing. The method's 
              elegance lies in its ability to simultaneously smooth data and compute derivatives with minimal distortion.
            </p>
          </div>
        </div>
      </EducationalSection>

      <EducationalSection
        title="How the Savitzky-Golay Filter Works"
        icon={<Calculator className="w-5 h-5 text-purple-600" />}
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            The Savitzky-Golay filter works by fitting a polynomial to a small window of data points 
            and using that polynomial to estimate the value and derivative at the center point.
          </p>

          <div className="bg-purple-50 p-4 rounded-lg">
            <h4 className="font-semibold text-purple-900 mb-3">Step-by-Step Process:</h4>
            <ol className="list-decimal list-inside space-y-2 text-purple-800">
              <li><strong>Select a Window:</strong> Choose a odd number of consecutive data points (we use 21)</li>
              <li><strong>Choose Polynomial Order:</strong> Decide the complexity of the fitting curve (we use cubic, order 3)</li>
              <li><strong>Fit the Polynomial:</strong> Use least-squares method to find the best-fitting polynomial</li>
              <li><strong>Evaluate at Center:</strong> Calculate the derivative of the polynomial at the window's center</li>
              <li><strong>Slide the Window:</strong> Move to the next point and repeat</li>
            </ol>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">Window Size (21 points)</h4>
              <p className="text-gray-700 text-sm">
                Larger windows provide more smoothing but less sensitivity to rapid changes. 
                21 points is a good balance for most applications.
              </p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">Polynomial Order (3)</h4>
              <p className="text-gray-700 text-sm">
                Cubic polynomials can capture complex curve shapes while remaining stable. 
                Higher orders risk overfitting to noise.
              </p>
            </div>
          </div>
        </div>
      </EducationalSection>

      <EducationalSection
        title="Our Processing Pipeline"
        icon={<Lightbulb className="w-5 h-5 text-orange-600" />}
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            This demonstration uses a two-step process to transform raw binary signals into smooth derivatives:
          </p>

          <div className="space-y-4">
            <div className="bg-orange-50 p-4 rounded-lg">
              <h4 className="font-semibold text-orange-900 mb-2">Step 1: Triangular Filtering</h4>
              <p className="text-orange-800 mb-2">
                First, we apply a triangular filter to the raw binary signal to create an initial smoothed version.
              </p>
              <div className="bg-white p-3 rounded border">
                <code className="text-sm">h[t] = 1 - |t|/15 for t ∈ [-15, 15]</code>
              </div>
              <p className="text-orange-800 text-sm mt-2">
                This filter gives maximum weight to the center point and linearly decreases weights toward the edges.
              </p>
            </div>

            <div className="bg-orange-50 p-4 rounded-lg">
              <h4 className="font-semibold text-orange-900 mb-2">Step 2: Savitzky-Golay Differentiation</h4>
              <p className="text-orange-800 mb-2">
                Then, we apply the Savitzky-Golay filter to compute the derivative of the smoothed signal.
              </p>
              <ul className="list-disc list-inside space-y-1 text-orange-800 text-sm">
                <li>Window size: 21 points (±10 from center)</li>
                <li>Polynomial order: 3 (cubic)</li>
                <li>Output: First derivative at each point</li>
              </ul>
            </div>
          </div>

          <div className="bg-indigo-50 p-4 rounded-lg">
            <h4 className="font-semibold text-indigo-900 mb-2">Visualization Features</h4>
            <ul className="list-disc list-inside space-y-1 text-indigo-800 text-sm">
              <li><strong>Red vertical line:</strong> Current time position</li>
              <li><strong>Green/Red bars:</strong> Derivative intensity (positive/negative)</li>
              <li><strong>Polynomial curve:</strong> Shows the fitted cubic polynomial in real-time</li>
              <li><strong>Interactive timeline:</strong> Scrub through time to see how the filter responds</li>
            </ul>
          </div>
        </div>
      </EducationalSection>

      <EducationalSection
        title="Applications in Real World"
        icon={<Lightbulb className="w-5 h-5 text-teal-600" />}
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            The Savitzky-Golay filter is used in numerous fields where smooth derivatives are needed:
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="bg-teal-50 p-3 rounded-lg">
                <h5 className="font-semibold text-teal-900">Spectroscopy</h5>
                <p className="text-teal-800 text-sm">Identifying peaks and analyzing chemical compositions</p>
              </div>
              
              <div className="bg-teal-50 p-3 rounded-lg">
                <h5 className="font-semibold text-teal-900">Financial Analysis</h5>
                <p className="text-teal-800 text-sm">Smoothing price data and detecting trend changes</p>
              </div>
              
              <div className="bg-teal-50 p-3 rounded-lg">
                <h5 className="font-semibold text-teal-900">Medical Monitoring</h5>
                <p className="text-teal-800 text-sm">Processing ECG, EEG, and other physiological signals</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="bg-teal-50 p-3 rounded-lg">
                <h5 className="font-semibold text-teal-900">Motion Tracking</h5>
                <p className="text-teal-800 text-sm">Computing smooth velocities and accelerations</p>
              </div>
              
              <div className="bg-teal-50 p-3 rounded-lg">
                <h5 className="font-semibold text-teal-900">Environmental Science</h5>
                <p className="text-teal-800 text-sm">Analyzing climate data and pollution measurements</p>
              </div>
              
              <div className="bg-teal-50 p-3 rounded-lg">
                <h5 className="font-semibold text-teal-900">Robotics</h5>
                <p className="text-teal-800 text-sm">Smooth sensor data processing and control</p>
              </div>
            </div>
          </div>
        </div>
      </EducationalSection>
    </div>
  );
};

export default EducationalContent;
