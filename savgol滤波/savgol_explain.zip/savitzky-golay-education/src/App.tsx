import React, { useState, useEffect, useMemo } from 'react';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Play, Pause, RotateCcw, Shuffle } from 'lucide-react';

import SignalChart from './components/charts/SignalChart';
import SGWindowVisualization from './components/charts/SGWindowVisualization';
import DerivativeBarsChart from './components/charts/DerivativeBarsChart';
import EducationalContent from './components/education/EducationalContent';

import { 
  generateRandomSignal, 
  processSignal 
} from './utils/signalProcessing';

function App() {
  // State management
  const [rawSignal, setRawSignal] = useState<number[]>(() => generateRandomSignal());
  const [currentTimeIndex, setCurrentTimeIndex] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(100); // ms between steps

  // Process the signal whenever rawSignal changes
  const processedData = useMemo(() => {
    return processSignal(rawSignal);
  }, [rawSignal]);

  // Prepare chart data
  const chartData = useMemo(() => {
    return rawSignal.map((raw, index) => ({
      index,
      raw,
      smoothed: processedData.smoothedSignal[index],
      derivative: processedData.derivative[index]
    }));
  }, [rawSignal, processedData]);

  // Auto-play functionality
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentTimeIndex(prev => {
        if (prev >= rawSignal.length - 1) {
          setIsPlaying(false);
          return 0;
        }
        return prev + 1;
      });
    }, playbackSpeed);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed, rawSignal.length]);

  // Control functions
  const handleGenerateNewSignal = () => {
    const newSignal = generateRandomSignal();
    setRawSignal(newSignal);
    setCurrentTimeIndex(10);
    setIsPlaying(false);
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setCurrentTimeIndex(0);
    setIsPlaying(false);
  };

  const handleTimeChange = (value: number[]) => {
    setCurrentTimeIndex(value[0]);
    setIsPlaying(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Interactive Savitzky-Golay Signal Differentiation
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explore real-time signal processing through interactive visualizations. 
            Watch how mathematical filters transform noisy data into smooth, meaningful derivatives.
          </p>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="interactive" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="interactive">Interactive Demo</TabsTrigger>
            <TabsTrigger value="education">Learn the Theory</TabsTrigger>
          </TabsList>

          <TabsContent value="interactive" className="space-y-6">
            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Interactive Controls</span>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleGenerateNewSignal}
                      className="gap-2"
                    >
                      <Shuffle className="w-4 h-4" />
                      New Signal
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleReset}
                      className="gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Reset
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      onClick={handlePlayPause}
                      className="gap-2"
                    >
                      {isPlaying ? (
                        <>
                          <Pause className="w-4 h-4" />
                          Pause
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4" />
                          Play
                        </>
                      )}
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Timeline Slider */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-sm font-medium text-gray-700">
                        Time Position: {currentTimeIndex}
                      </label>
                      <span className="text-sm text-gray-500">
                        Total: {rawSignal.length} points
                      </span>
                    </div>
                    <Slider
                      value={[currentTimeIndex]}
                      onValueChange={handleTimeChange}
                      max={rawSignal.length - 1}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Playback Speed */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">
                      Playback Speed: {playbackSpeed}ms per step
                    </label>
                    <Slider
                      value={[playbackSpeed]}
                      onValueChange={(value) => setPlaybackSpeed(value[0])}
                      max={500}
                      min={50}
                      step={25}
                      className="w-full"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Signal Charts */}
            <div className="grid gap-6">
              {/* Individual Signal Views */}
              <div className="grid lg:grid-cols-3 gap-4">
                <SignalChart
                  data={chartData}
                  derivativeBars={processedData.derivativeBars}
                  currentTimeIndex={currentTimeIndex}
                  title="Raw Signal A(t)"
                  showType="raw"
                  height={250}
                />
                <SignalChart
                  data={chartData}
                  derivativeBars={processedData.derivativeBars}
                  currentTimeIndex={currentTimeIndex}
                  title="Smoothed Signal p(t)"
                  showType="smoothed"
                  height={250}
                />
                <SignalChart
                  data={chartData}
                  derivativeBars={processedData.derivativeBars}
                  currentTimeIndex={currentTimeIndex}
                  title="Derivative dp/dt"
                  showType="derivative"
                  height={250}
                />
              </div>

              {/* Combined View */}
              <SignalChart
                data={chartData}
                derivativeBars={processedData.derivativeBars}
                currentTimeIndex={currentTimeIndex}
                title="Complete Signal Processing Pipeline"
                showType="all"
                height={400}
              />

              {/* SG Window Visualization */}
              {currentTimeIndex < processedData.windowData.length && (
                <SGWindowVisualization
                  windowData={processedData.windowData[currentTimeIndex]}
                  smoothedSignal={processedData.smoothedSignal}
                  currentTimeIndex={currentTimeIndex}
                />
              )}

              {/* Derivative Bars */}
              <DerivativeBarsChart
                smoothedSignal={processedData.smoothedSignal}
                derivative={processedData.derivative}
                currentTimeIndex={currentTimeIndex}
              />
            </div>

            {/* Signal Statistics */}
            <Card>
              <CardHeader>
                <CardTitle>Current Signal Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <div className="text-2xl font-bold text-red-600">
                      {rawSignal[currentTimeIndex]}
                    </div>
                    <div className="text-sm text-red-700">Raw Value</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {processedData.smoothedSignal[currentTimeIndex]?.toFixed(3) || '0.000'}
                    </div>
                    <div className="text-sm text-green-700">Smoothed Value</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {processedData.derivative[currentTimeIndex]?.toFixed(4) || '0.0000'}
                    </div>
                    <div className="text-sm text-blue-700">Derivative</div>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {processedData.derivative[currentTimeIndex] >= 0 ? '↗' : '↘'}
                    </div>
                    <div className="text-sm text-purple-700">
                      {processedData.derivative[currentTimeIndex] >= 0 ? 'Increasing' : 'Decreasing'}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="education">
            <EducationalContent />
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="mt-12 text-center text-gray-500 text-sm">
          <p>
            Interactive Savitzky-Golay Filter Demonstration • 
            Built with React, TypeScript, and Mathematical Precision
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;
