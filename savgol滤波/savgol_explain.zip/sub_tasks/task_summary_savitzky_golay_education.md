# savitzky_golay_education

# Interactive Savitzky-Golay Signal Differentiation Educational Webpage

## Project Overview
Successfully created a comprehensive educational webpage that demonstrates real-time signal differentiation using Savitzky-Golay filters. The application transforms complex mathematical concepts into accessible, interactive visualizations suitable for non-technical audiences.

## Key Achievements

### Mathematical Implementation
- **Triangular Filter**: Implemented h[t] = 1 - |t|/15 for t∈[-15,15] with proper normalization
- **Savitzky-Golay Filter**: Complete cubic polynomial fitting (order 3) with 21-point window
- **Matrix Operations**: Custom matrix multiplication, transpose, and inversion for polynomial fitting
- **Signal Processing Pipeline**: Two-step process from raw binary signals to smooth derivatives

### Interactive Features
- **Real-time Timeline Scrubbing**: Smooth navigation through 100 data points with synchronized visualizations
- **Play/Pause Controls**: Automated playback with adjustable speed (50-500ms per step)
- **Dynamic Signal Generation**: Random binary sequence generator following specified patterns
- **Multi-view Visualization**: Individual and combined views of raw, smoothed, and derivative signals

### Educational Content
- **Comprehensive Theory Section**: Covers signal processing fundamentals, SG filter history, and applications
- **Historical Context**: Detailed information about Abraham Savitzky and Marcel J.E. Golay
- **Step-by-step Explanations**: Clear breakdown of the mathematical processing pipeline
- **Real-world Applications**: Examples from spectroscopy, finance, medical monitoring, and robotics

### Advanced Visualizations
- **SG Window Analysis**: Real-time display of polynomial fitting process with mathematical equations
- **Derivative Intensity Bars**: Color-coded visualization showing rate of change (green/red for positive/negative)
- **Synchronized Charts**: All visualizations update simultaneously with timeline interaction
- **Professional Design**: Clean, responsive layout with intuitive controls and clear legends

## Technical Implementation

### Architecture
- **React 18 + TypeScript**: Type-safe development with modern hooks and state management
- **Recharts Library**: Professional charting with customizable tooltips and interactive elements
- **TailwindCSS**: Responsive design with consistent styling and animations
- **Mathematical Utilities**: Custom signal processing functions without external dependencies

### Performance Optimizations
- **Memoized Computations**: Efficient signal processing with React.useMemo
- **Real-time Updates**: Smooth timeline scrubbing without performance degradation
- **Responsive Design**: Optimized for desktop and mobile viewing

## Testing Results
Comprehensive browser testing confirmed:
- ✅ All interactive features function correctly
- ✅ Mathematical calculations are accurate
- ✅ Educational content is well-formatted and accessible
- ✅ No console errors or visual issues
- ✅ Smooth performance during real-time interaction
- ✅ Professional visual design suitable for educational use

## Deployment
Successfully deployed to production environment with full functionality verified through automated testing.

## Impact
This educational tool makes advanced signal processing concepts accessible to non-technical audiences while maintaining mathematical rigor, serving as an excellent resource for students, educators, and professionals learning about digital signal processing.

## Key Files

- savitzky-golay-education/src/App.tsx: Main application component with interactive controls, timeline, and chart orchestration
- savitzky-golay-education/src/utils/signalProcessing.ts: Core mathematical functions implementing triangular filter and Savitzky-Golay differentiation
- savitzky-golay-education/src/components/charts/SignalChart.tsx: Reusable chart component for displaying raw, smoothed, and derivative signals
- savitzky-golay-education/src/components/charts/SGWindowVisualization.tsx: Specialized component for visualizing Savitzky-Golay window and polynomial fitting
- savitzky-golay-education/src/components/charts/DerivativeBarsChart.tsx: Component for rendering color-coded derivative intensity bars
- savitzky-golay-education/src/components/education/EducationalContent.tsx: Comprehensive educational content covering SG filter theory, history, and applications
